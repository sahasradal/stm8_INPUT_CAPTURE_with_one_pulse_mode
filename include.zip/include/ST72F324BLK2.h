/* ST72F324BLK2.h */
#ifdef MCU_NAME
#define ST72F324BLK2 1
#endif
#include "ST72324.h"
