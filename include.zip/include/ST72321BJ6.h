/* ST72321BJ6.h */
#ifdef MCU_NAME
#define ST72321BJ6 1
#endif
#include "ST72321.h"
