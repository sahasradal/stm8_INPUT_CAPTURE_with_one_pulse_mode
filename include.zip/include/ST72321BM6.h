/* ST72321BM6.h */
#ifdef MCU_NAME
#define ST72321BM6 1
#endif
#include "ST72F321M6.h"
