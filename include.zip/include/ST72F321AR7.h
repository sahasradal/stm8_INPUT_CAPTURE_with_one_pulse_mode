/* ST72F321AR7.h */
#ifdef MCU_NAME
#define ST72F321AR7 1
#endif
#include "ST72321.h"
