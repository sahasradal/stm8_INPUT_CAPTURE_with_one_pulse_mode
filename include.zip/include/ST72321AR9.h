/* ST72321AR9.h */
#ifdef MCU_NAME
#define ST72321AR9 1
#endif
#include "ST72321.h"
