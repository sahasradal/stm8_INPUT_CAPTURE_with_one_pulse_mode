/* ST72F344K4.h */
#ifdef MCU_NAME
#define ST72F344K4 1
#endif
#include "ST72344.h"
