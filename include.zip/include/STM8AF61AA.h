/* STM8AF61AA.h */
#ifdef MCU_NAME
#define STM8AF61AA 1
#endif
#include "STM8AF61xA.h"
