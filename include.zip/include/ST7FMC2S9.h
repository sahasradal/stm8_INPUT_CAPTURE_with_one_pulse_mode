/* ST7FMC2S9.h */
#ifdef MCU_NAME
#define ST7FMC2S9 1
#endif
#include "ST7FMC2S6.h"
