/* ST72F60K2.h */
#ifdef MCU_NAME
#define ST72F60K2 1
#endif
#include "ST7260.h"
