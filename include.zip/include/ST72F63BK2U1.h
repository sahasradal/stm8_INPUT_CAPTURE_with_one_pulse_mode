/* ST72F63BK2U1.h */
#ifdef MCU_NAME
#define ST72F63BK2U1 1
#endif
#include "ST7263BK6.h"
