/* ST72F321AR6.h */
#ifdef MCU_NAME
#define ST72F321AR6 1
#endif
#include "ST72321.h"
