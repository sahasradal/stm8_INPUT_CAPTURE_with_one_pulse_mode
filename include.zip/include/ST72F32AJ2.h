/* ST72F32AJ2.h */
#ifdef MCU_NAME
#define ST72F32AJ2 1
#endif
#include "ST7232A.h"
