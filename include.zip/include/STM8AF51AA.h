/* STM8AF51AA.h */
#ifdef MCU_NAME
#define STM8AF51AA 1
#endif
#include "STM8AF51xA.h"
