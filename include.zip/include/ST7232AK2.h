/* ST7232AK2.h */
#ifdef MCU_NAME
#define ST7232AK2 1
#endif
#include "ST7232A.h"
