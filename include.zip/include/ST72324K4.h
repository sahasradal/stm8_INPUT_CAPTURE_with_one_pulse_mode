/* ST72324K4.h */
#ifdef MCU_NAME
#define ST72324K4 1
#endif
#include "ST72324.h"
