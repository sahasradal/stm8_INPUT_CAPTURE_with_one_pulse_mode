/* ST7FLIT19BY0.h */
#ifdef MCU_NAME
#define ST7FLIT19BY0 1
#endif
#include "ST7LITE19B.h"
