/* STM8AF62A9.h */
#ifdef MCU_NAME
#define STM8AF62A9 1
#endif
#include "STM8AF61x9.h"
