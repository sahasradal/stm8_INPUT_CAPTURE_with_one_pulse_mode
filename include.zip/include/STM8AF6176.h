/* STM8AF6176.h */
#ifdef MCU_NAME
#define STM8AF6176 1
#endif
#include "STM8AF61x6.h"
