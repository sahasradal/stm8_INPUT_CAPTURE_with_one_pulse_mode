/* STM8AH519A.h */
#ifdef MCU_NAME
#define STM8AH519A 1
#endif
#include "STM8AF51xA.h"
