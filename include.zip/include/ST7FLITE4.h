/* ST7FLITE4.h */
#ifdef MCU_NAME
#define ST7FLITE4 1
#endif
#include "ST7FLI49K2T6.h"
