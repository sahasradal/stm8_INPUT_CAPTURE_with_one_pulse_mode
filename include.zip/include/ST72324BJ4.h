/* ST72324BJ4.h */
#ifdef MCU_NAME
#define ST72324BJ4 1
#endif
#include "ST72324.h"
