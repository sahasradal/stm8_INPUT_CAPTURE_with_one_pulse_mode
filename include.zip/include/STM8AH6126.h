/* STM8AH6126.h */
#ifdef MCU_NAME
#define STM8AH6126 1
#endif
#include "STM8AF61x6.h"
