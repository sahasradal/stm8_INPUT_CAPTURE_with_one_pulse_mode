/* ST72325J4.h */
#ifdef MCU_NAME
#define ST72325J4 1
#endif
#include "ST72325.h"
