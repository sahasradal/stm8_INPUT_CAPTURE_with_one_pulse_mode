/* STM8AF6246.h */
#ifdef MCU_NAME
#define STM8AF6246 1
#endif
#include "STM8AF61x6.h"
