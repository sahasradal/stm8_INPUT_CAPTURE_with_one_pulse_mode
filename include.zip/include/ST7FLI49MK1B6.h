/* ST7FLI49MK1B6.h */
#ifdef MCU_NAME
#define ST7FLI49MK1B6 1
#endif
#include "ST7FLI49MK1T6.h"
