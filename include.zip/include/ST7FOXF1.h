/* ST7FOXF1.h */
#ifdef MCU_NAME
#define ST7FOXF1 1
#endif
#include "ST7FOXK1.h"
