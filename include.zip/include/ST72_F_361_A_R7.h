/* ST72_F_361_A_R7.h */
#ifdef MCU_NAME
#define ST72_F_361_A_R7 1
#endif
#include "ST72361AR.h"
