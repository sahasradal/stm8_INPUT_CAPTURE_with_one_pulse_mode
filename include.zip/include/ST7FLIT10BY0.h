/* ST7FLIT10BY0.h */
#ifdef MCU_NAME
#define ST7FLIT10BY0 1
#endif
#include "ST7LITE10B.h"
