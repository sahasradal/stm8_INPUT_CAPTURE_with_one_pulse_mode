/* ST72324BLJ4.h */
#ifdef MCU_NAME
#define ST72324BLJ4 1
#endif
#include "ST72324.h"
