/* ST7FLITEU0ICD.h */
#ifdef MCU_NAME
#define ST7FLITEU0ICD 1
#endif
#include "ST7FLITEU09.h"
