/* ST72F325C6.h */
#ifdef MCU_NAME
#define ST72F325C6 1
#endif
#include "ST72325.h"
