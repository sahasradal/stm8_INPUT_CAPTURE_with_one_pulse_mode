/* STM8AH6166.h */
#ifdef MCU_NAME
#define STM8AH6166 1
#endif
#include "STM8AF61x6.h"
