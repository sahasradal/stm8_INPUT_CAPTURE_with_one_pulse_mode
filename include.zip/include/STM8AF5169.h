/* STM8AF5169.h */
#ifdef MCU_NAME
#define STM8AF5169 1
#endif
#include "STM8AF51x9.h"
