/* ST72321_A_R7.h */
#ifdef MCU_NAME
#define ST72321_A_R7 1
#endif
#include "ST72321.h"
