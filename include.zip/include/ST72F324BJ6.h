/* ST72F324BJ6.h */
#ifdef MCU_NAME
#define ST72F324BJ6 1
#endif
#include "ST72324.h"
