/* ST72F63BK6.h */
#ifdef MCU_NAME
#define ST72F63BK6 1
#endif
#include "ST7263BK6.h"
