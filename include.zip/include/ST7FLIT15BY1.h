/* ST7FLIT15BY1.h */
#ifdef MCU_NAME
#define ST7FLIT15BY1 1
#endif
#include "ST7LITE15B.h"
