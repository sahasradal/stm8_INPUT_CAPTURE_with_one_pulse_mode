/* ST7260E2.h */
#ifdef MCU_NAME
#define ST7260E2 1
#endif
#include "ST7260.h"
