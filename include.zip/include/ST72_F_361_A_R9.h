/* ST72_F_361_A_R9.h */
#ifdef MCU_NAME
#define ST72_F_361_A_R9 1
#endif
#include "ST72361AR.h"
