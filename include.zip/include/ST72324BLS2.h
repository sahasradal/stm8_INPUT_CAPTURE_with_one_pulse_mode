/* ST72324BLS2.h */
#ifdef MCU_NAME
#define ST72324BLS2 1
#endif
#include "ST72324.h"
